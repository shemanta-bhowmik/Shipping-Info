<?php

  /**
 * Shipping Info
 *
 * @package           ShippingInfoPackage
 * @author            Shemanta Bhowmik
 * @copyright         
 * @license           GPL-2.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name:       Shipping Info
 * Plugin URI:        #
 * Description:       This is a shipping info plugin. Use <strong>[sb_shipping_info]</strong> this shortcode to show the output.
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Shemanta Bhowmik
 * Author URI:        https://shemantabhowmik.com/
 * Text Domain:       shipping-info
 * License:           GPL v2 or later
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Update URI:        #
 */


  function shipping_info_sc() {

    function shipping_info_func() {

      ob_start(); ?>

      <link rel="stylesheet" href="<?php echo plugin_dir_url( __FILE__ ); ?>style.css">

      <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
      <script src="<?php echo plugin_dir_url( __FILE__ ); ?>js/dayjs.min.js"></script>
      <script src="<?php echo plugin_dir_url( __FILE__ ); ?>/js/custom.js"></script>

      <body>

        <div class="row-width">
          <div class="input-box">
            <!-- Default Country - "United States" -->
            <div class="child-input-boxes">
              <label>Country/Region</label>
              <br>
              United States
            </div>
            <!-- States of USA -->
            <div class="child-input-boxes">
              <label for="cities-label">State/Province</label>
              <select name="" id="state-province">
                <option>Select State</option>
                <option value="AL">Alabama</option>
                <option value="AK">Alaska</option>
                <option value="AZ">Arizona</option>
                <option value="AR">Arkansas</option>
                <option value="CA">California</option>
                <option value="CO">Colorado</option>
                <option value="CT">Connecticut</option>
                <option value="DE">Delaware</option>
                <option value="DC">District Of Columbia</option>
                <option value="FL">Florida</option>
                <option value="GA">Georgia</option>
                <option value="HI">Hawaii</option>
                <option value="ID">Idaho</option>
                <option value="IL">Illinois</option>
                <option value="IN">Indiana</option>
                <option value="IA">Iowa</option>
                <option value="KS">Kansas</option>
                <option value="KY">Kentucky</option>
                <option value="LA">Louisiana</option>
                <option value="ME">Maine</option>
                <option value="MD">Maryland</option>
                <option value="MA">Massachusetts</option>
                <option value="MI">Michigan</option>
                <option value="MN">Minnesota</option>
                <option value="MS">Mississippi</option>
                <option value="MO">Missouri</option>
                <option value="MT">Montana</option>
                <option value="NE">Nebraska</option>
                <option value="NV">Nevada</option>
                <option value="NH">New Hampshire</option>
                <option value="NJ">New Jersey</option>
                <option value="NM">New Mexico</option>
                <option value="NY">New York</option>
                <option value="NC">North Carolina</option>
                <option value="ND">North Dakota</option>
                <option value="OH">Ohio</option>
                <option value="OK">Oklahoma</option>
                <option value="OR">Oregon</option>
                <option value="PA">Pennsylvania</option>
                <option value="RI">Rhode Island</option>
                <option value="SC">South Carolina</option>
                <option value="SD">South Dakota</option>
                <option value="TN">Tennessee</option>
                <option value="TX">Texas</option>
                <option value="UT">Utah</option>
                <option value="VT">Vermont</option>
                <option value="VA">Virginia</option>
                <option value="WA">Washington</option>
                <option value="WV">West Virginia</option>
                <option value="WI">Wisconsin</option>
                <option value="WY">Wyoming</option>
              </select>
            </div>

            <!-- Cities of Alabama -->
            <!-- <div class="child-input-boxes display-none" id="alabama-cities">
              <label for="cities-label">City</label>
              <select name="" id="city-province">
                <option value="">Select City</option>
                <option value="dhk">Abbeville</option>
                <option value="ctg">Abernant</option>
                <option value="ku">Adamsville</option>
                <option value="ng">Addison</option>
              </select>
            </div> -->

          </div>
                  
          <br><br>
        
          <!-- Shipping Information Table -->
          <div id="shipping-info-table">
            <table class="product-ship__table">
              <tr tabindex="0" class="tr-head">
                  <td>Shipping Method</td>
                  <td>Shipping Time</td>
                  <td>Costs</td>
              </tr>
              <tr tabindex="0">
                  <td class="title">
                      STANDARD SHIPPING
                  </td>
                  <td>
                      Estimated to be delivered on <span id="earliest-date">11days</span> - <span id="lastest-date">14days</span>
                  </td>
                  <td>
                      <div>
                          <div> US$3.99 </div>
                          <div class="free">
                              Free - orders over US$49.00
                          </div>
                      </div>
                  </td>
              </tr>
              <tr tabindex="0">
                  <td class="title">
                      EXPRESS SHIPPING
                  </td>
                  <td>
                      Estimated to be delivered on <span id="express-earliest-date">11days</span> - <span id="express-lastest-date">14days</span>
                  </td>
                  <td>
                      <div>
                          <div> US$12.90 </div>
                          <div class="free">
                              Free - orders over US$199.00
                          </div>
                      </div>
                  </td>
              </tr>
            </table>
          </div>
          
          <!-- Notes -->
          <div class="shipping-info-notes">
            <div class="notes">
              <h4 class="notes-title"><strong>Notes:<strong></h4>
              <ul>
                <li>1) Express Shipping is not available for P.O. Boxes and APO/FPO addresses.</li>
                <li>2) After the order has been paid, the warehouse needs 1-3 days to process your order. You will receive a notification once your order has been shipped.</li>
                <li>3) In most cases, the package will be delivered within the estimated time of arrival. However, the actual delivery date may be affected by flight arrangements, weather conditions and other external factors. Please refer to the tracking information for the most accurate delivery date.</li>
                <li>4) If your package has not been delivered or your tracking information shows that your package has been delivered but you have not received it, you must contact Customer Service to verify within 45 days of the order date. For other orders, products, and logistics related issues, you must contact customer service within 90 days of the order date.</li>
                <li>5) Please click the "Confirm Delivery" button within 6 months (from the date of shipment). After that, the button will turn gray and cannot be used to get additional points.</li>
              </ul>
            </div>
          </div>
        </div>

      </body>
      </html>

      <?php return ob_get_clean();

    }
    add_shortcode( 'sb_shipping_info', 'shipping_info_func' );

  }
  add_action( 'init', 'shipping_info_sc' );
