jQuery( document ).ready( function() {

    /**
     * Dynamic Date Section
     * 
     */

     var earlistDate = document.getElementById( 'earliest-date' ).innerText = dayjs().add(11, 'day').format('MM/DD/YYYY');
     var latestDate = document.getElementById( 'lastest-date' ).innerText = dayjs().add(14, 'day').format('MM/DD/YYYY');
 
     var expressEarliestDate = document.getElementById( 'express-earliest-date' ).innerText = dayjs().add(9, 'day').format('MM/DD/YYYY');
     var expressLatestDate = document.getElementById( 'express-lastest-date' ).innerText = dayjs().add(11, 'day').format('MM/DD/YYYY');
 

    /**
     * Sate Province Section
     * 
     */

    jQuery( '#state-province' ).change( function(){

        let cities = jQuery( '#state-province' ).val();
        
        // Alaska
        if ( cities == 'AK' || cities == 'HI' ) {
            // jQuery( '#ap-cities' ).css( 'display', 'block' );
            document.getElementById( 'shipping-info-table' ).innerHTML = '<table class="product-ship__table"> <tr tabindex="0" class="tr-head"> <td>Shipping Method</td><td>Shipping Time</td><td>Costs</td></tr><tr tabindex="0"> <td class="title"> STANDARD SHIPPING </td><td> Estimated to be delivered on <span id="earliest-date">' + earlistDate + '</span> - <span id="lastest-date">' + latestDate + '</span> </td><td> <div> <div> US$3.99 </div><div class="free"> Free - orders over US$49.00 </div></div></td></tr></table>';
        } else {
            // jQuery( '#ap-cities' ).css( 'display', 'none' );
            document.getElementById( 'shipping-info-table' ).innerHTML = '<table class="product-ship__table"> <tr tabindex="0" class="tr-head"> <td>Shipping Method</td><td>Shipping Time</td><td>Costs</td></tr><tr tabindex="0"> <td class="title"> STANDARD SHIPPING </td><td> Estimated to be delivered on <span id="earliest-date">' + earlistDate + '</span> - <span id="lastest-date">' + latestDate + '</span> </td><td> <div> <div> US$3.99 </div><div class="free"> Free - orders over US$49.00 </div></div></td></tr><tr tabindex="0"> <td class="title"> EXPRESS SHIPPING </td><td> Estimated to be delivered on <span id="express-earliest-date">' + expressEarliestDate + '</span> - <span id="express-lastest-date">' + expressLatestDate + '</span> </td><td> <div> <div> US$12.90 </div><div class="free"> Free - orders over US$199.00 </div></div></td></tr></table>';
        }


    } );


} );